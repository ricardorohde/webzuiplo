<!-- <div id="main-wrapper">
    <div id="main">
        <div id="main-inner">

<div class="block-content no-padding">
    <div class="block-content-inner">
        <div class="map-wrapper"> -->
            <div id="map" data-style="1">
            </div>
    <script>
      var infowindow;
      var circle;
      var image_here = '<?php echo base_url('assets/images/zuiplo/user-pin.png');?>';
        function initMap()
          {
            var map = new google.maps.Map(document.getElementById('map'),
              {
                zoom: 10,
                center: {lat: -6.204831, lng: 106.840848}
              });
            var geocoder = new google.maps.Geocoder();
              document.getElementById('submit').addEventListener('click', function()
                {
                  geocodeAddress(geocoder, map);
                });
              }

        function geocodeAddress(geocoder, resultsMap) {
            var address = document.getElementById('address').value;
              geocoder.geocode({'address': address}, function(results, status) {
                if (status === google.maps.GeocoderStatus.OK) {
                  resultsMap.setCenter(results[0].geometry.location);
                  var marker = new google.maps.Marker({
                    map: resultsMap,
                    position: results[0].geometry.location,
                    icon: image_here,
                    zoom:90,
                    animation: google.maps.Animation.DROP
                });
                  var infowindow = new google.maps.InfoWindow();
                    google.maps.event.addListener(marker, 'click', function() {
                        infowindow.setContent('<div><strong>Youre Location</strong><br>'+ address  + '<br>' + '</div>');
                        infowindow.open(resultsMap, this);
                });
                  var lat = results[0].geometry.location.lat();
                  var lng = results[0].geometry.location.lng();
                    circle = new google.maps.Circle({
                    strokeColor: '#FF0000',
                    strokeOpacity: 0,
                    strokeWeight: 2,
                    fillColor: '#FF0000',
                    fillOpacity: 0,
                    map: resultsMap,
                    center: results[0].geometry.location,
                    radius: 3000
                  });
                    <?php foreach ($view->result() as $key => $row) {  ?>

                      var latview = '<?php echo $row->lat ?>';
                        var longview = '<?php echo $row->lng ?>';
                      var image = '<?php echo base_url('assets/images/zuiplo/find-pin.png');?>';
                      var latLng = new google.maps.LatLng(latview,longview);
                      var marker = new google.maps.Marker({
                        position: latLng,
                        icon: image,
                        map: resultsMap
                      });
                      var infowindow = new google.maps.InfoWindow();
                        google.maps.event.addListener(marker, 'click', function() {

                        infowindow.open(resultsMap, this);
                    });
                      var distanceInMetres = google.maps.geometry.spherical.computeDistanceBetween(circle.center, latLng);

                          if(distanceInMetres > circle.radius){
                            marker.setMap(null);
                          }
                          <?php } ?>
                        } else {
                            alert('Geocode was not successful for the following reason: ' + status);
                          }
                            document.getElementById('lat').value = lat;
                            document.getElementById('lng').value=lng;
                          });
                        }
                var marker = null;
                  function initialize() {
                      var mapOptions = {
                        center: new google.maps.LatLng(-6.175486, 106.825407),
                        zoom: 15
                      };
                      var map = new google.maps.Map(document.getElementById("map-canvas"),
                      mapOptions);
                      google.maps.event.addListener(map, 'click', function(event)
                      {
                        if (marker != undefined){
                          marker.setMap(null);
                          marker=null;
                        }
                        if (marker == null) {
                          marker = new google.maps.Marker({
                          position: event.latLng,
                          map: map,
                          title: 'Your base',
                          draggable: true,
                          animation: google.maps.Animation.DROP
                          });
                  updateFieldsAndCenter(map, marker);
                  google.maps.event.addListener(marker, 'dragend', function() {
                    updateFieldsAndCenter(map, marker);
                     map.setZoom(18);
                  });
                }

              });
            }
            function callback(results, status)
            {
              if (status === google.maps.GeocoderStatus.OK) {
                  if (status === google.maps.places.PlacesServiceStatus.OK) {
                    for (var i = 0; i < results.length; i++) {
                        createMarker(results[i]);
                        console.log('a');
                    }
                  }
                }
            }
            function createMarker(place) {
              var placeLoc = place.geometry.location;
              var marker = new google.maps.Marker({
                map: resultsMap,
                position: place.geometry.location
              });
                google.maps.event.addListener(marker, 'click', function() {
                infowindow.setContent(place.name);
                infowindow.open(resultsMap, this);
              });
              }
              function updateMapAndCenter(map, marker) {
                window.setTimeout(function() {
                map.panTo(marker.getPosition());
              }, 3000);
            }
              function updateFieldsAndCenter(map, marker) {
              window.setTimeout(function() {
                map.panTo(marker.getPosition());
                }, 3000);
                document.getElementById("_lat").value = marker.getPosition().lat();
                document.getElementById("_lng").value = marker.getPosition().lng();
            }
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?libraries=geometry&key=AIzaSyAz7xYV8gxtSq4_IE8aGv2L6Wx9vyzQtnc&callback=initMap"></script>
  <!-- <script src="https://maps.googleapis.com/maps/api/js?libraries=geometry&key=AIzaSyAz7xYV8gxtSq4_IE8aGv2L6Wx9vyzQtnc"></script> -->
<style media="screen">
  .img-responsive{
    height: 245px;
  }
</style>
